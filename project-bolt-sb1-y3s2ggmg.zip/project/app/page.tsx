import Link from 'next/link';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { BookOpen, Plus, List, Edit, Trash2 } from 'lucide-react';

export default function Home() {
  const features = [
    {
      icon: <List className="h-8 w-8 text-blue-600" />,
      title: 'List Posts',
      description: 'View all posts with pagination and filtering',
      href: '/posts'
    },
    {
      icon: <Plus className="h-8 w-8 text-green-600" />,
      title: 'Create Posts',
      description: 'Add new posts with form validation',
      href: '/posts/create'
    },
    {
      icon: <Edit className="h-8 w-8 text-yellow-600" />,
      title: 'Edit Posts',
      description: 'Update existing posts with pre-filled forms',
      href: '/posts'
    },
    {
      icon: <Trash2 className="h-8 w-8 text-red-600" />,
      title: 'Delete Posts',
      description: 'Remove posts with confirmation dialogs',
      href: '/posts'
    }
  ];

  return (
    <div className="container mx-auto px-4 py-8">
      <div className="text-center mb-12">
        <div className="flex items-center justify-center mb-4">
          <BookOpen className="h-12 w-12 text-blue-600 mr-3" />
          <h1 className="text-4xl font-bold text-gray-900">CRUD App</h1>
        </div>
        <p className="text-xl text-gray-600 max-w-2xl mx-auto">
          A comprehensive Next.js CRUD application for interview preparation. 
          Features all essential topics including React hooks, API routes, database operations, and modern UI patterns.
        </p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
        {features.map((feature, index) => (
          <Card key={index} className="hover:shadow-lg transition-shadow">
            <CardHeader className="text-center">
              <div className="flex justify-center mb-2">
                {feature.icon}
              </div>
              <CardTitle className="text-lg">{feature.title}</CardTitle>
            </CardHeader>
            <CardContent>
              <CardDescription className="text-center mb-4">
                {feature.description}
              </CardDescription>
              <Link href={feature.href}>
                <Button className="w-full" variant="outline">
                  Explore
                </Button>
              </Link>
            </CardContent>
          </Card>
        ))}
      </div>

      <div className="text-center">
        <Link href="/posts">
          <Button size="lg" className="text-lg px-8 py-3">
            Get Started with Posts
          </Button>
        </Link>
      </div>

      <div className="mt-16 bg-white rounded-lg p-8 shadow-sm">
        <h2 className="text-2xl font-semibold mb-4 text-center">What You'll Learn</h2>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          <div className="text-center">
            <h3 className="font-semibold text-lg mb-2">React Hooks</h3>
            <p className="text-gray-600">useState, useEffect, and custom hooks for state management</p>
          </div>
          <div className="text-center">
            <h3 className="font-semibold text-lg mb-2">Next.js Routing</h3>
            <p className="text-gray-600">App Router, dynamic routes, and navigation patterns</p>
          </div>
          <div className="text-center">
            <h3 className="font-semibold text-lg mb-2">API Routes</h3>
            <p className="text-gray-600">RESTful endpoints for CRUD operations</p>
          </div>
          <div className="text-center">
            <h3 className="font-semibold text-lg mb-2">Database Operations</h3>
            <p className="text-gray-600">Prisma ORM with PostgreSQL database</p>
          </div>
          <div className="text-center">
            <h3 className="font-semibold text-lg mb-2">Form Handling</h3>
            <p className="text-gray-600">Form validation, submission, and error handling</p>
          </div>
          <div className="text-center">
            <h3 className="font-semibold text-lg mb-2">Modern UI</h3>
            <p className="text-gray-600">Tailwind CSS and shadcn/ui components</p>
          </div>
        </div>
      </div>
    </div>
  );
}